export const colors = {
  colorA: "#ff7c70",
  colorB: "#f2dfb1",
  colorC: "#b7c9a9",
  colorD: "#674d69",
  colorE: "#2e292e",
};
